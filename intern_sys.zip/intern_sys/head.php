<nav class = "navbar navbar-default navbar-fixed-top">
	<div class = "container-fluid">
		<a href="index.php" class = "navbar-brand">NITCOM</a>
	<div>
</nav>