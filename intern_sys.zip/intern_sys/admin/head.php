<nav class = "navbar navbar-default navbar-fixed-top">
	<div class = "container-fluid">
		<a class="navbar-brand" href="#">
		</a>
		<a class = "navbar-brand">NITCOM </a>
	<div>
</nav>