
<div id = "home" class = "tab-pane fade in active">
	<div id="myCarousel" class="carousel slide container-fluid" data-ride="carousel">
		<ol class="carousel-indicators">
			<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
			<li data-target="#myCarousel" data-slide-to="1"></li>
			<li data-target="#myCarousel" data-slide-to="2"></li>
			<li data-target="#myCarousel" data-slide-to="3"></li>
			<li data-target="#myCarousel" data-slide-to="4"></li>
			<li data-target="#myCarousel" data-slide-to="5"></li>
			<li data-target="#myCarousel" data-slide-to="6"></li>
			
		</ol>
		<div style = "margin:auto;" class="carousel-inner" role="listbox">
			<div class="item active">
				<img src="images/course-1.jpg" style = "width:1520px; height:500px;",align='centre' />
			</div>
			<div class="item">
				<img src="images/C2.jpg" style = "width:1520px; height:500px;"  />
			</div>
			<div class="item">
				<img src="images/course-3.jpg" style = "width:1520px; height:500px;"  />
			</div>
			<div class="item">
				<img src="images/events-1.jpg" style = "width:1520px; height:500px;"  />
			</div>
		</div>
		<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
			<span class="sr-only">Previous</span>
		</a>
		<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
			<span class="sr-only">Next</span>
		</a>	
	</div>
	<br />
	<hr style = "border-top:1px dotted #000;" />
	<div class = "container-fluid">
		<div class = "alert alert-success"><center><h3>Goal of the NITCOM platform </h3><center></div>
		<h4>NITCOM aims to</h4>
		<ol>
			<li><h4>Produce Users with technical skills </h4></li>
			<li><h4>Develop creative innovators with the confidence and courage to seize and transform opportunities for the benefit of the society</h4></li>
			<li><h4>Provide continues specialized faculty training and professional development</h4></li>
			<li><h4>Acquire implement and utilize technologies to support for the instructional, administrative, research, and development and extensive needs</h4></li>
			<li><h4>Provide students with all the resource to enrich their educational experience and work experience </h4></li>
			
		</ol>
	</div>
</div>